<div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
  <div style="margin:50px auto;width:70%;padding:20px 0">
    <div style="border-bottom:1px solid #eee">
      <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Leavs System</a>
    </div>
    <p style="font-size:1.1em">Hi <?php echo e($user->name); ?>,</p>
    <p>Use the following OTP to Reset Your Password.</p>
    <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;"><?php echo e($user->tokens->token); ?></h2>
    <p style="font-size:0.9em;">Regards, </p>
    
    </div>
  </div>
</div><?php /**PATH C:\wamp64\www\leaves\resources\views/emails/forgot-password-otp.blade.php ENDPATH**/ ?>