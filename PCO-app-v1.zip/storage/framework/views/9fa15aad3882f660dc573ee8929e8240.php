<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class=" flex justify-between">

            <div class="flex">
                <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                    <?php echo e(__('Users List')); ?>

                </h2>
            </div>
            <div class="flex">
                <a href="<?php echo e(route('user.add')); ?>" >
                    <i class="fa-plus"></i>    Add User
                </a>    
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-error">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
            <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg mb-4">
                    <table class="table w-full border mb-4">
                        <tr>
                            <th>Sr</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Type</th>
                            <th>Status</th>
                            <th colspan="2">Action</th>
                        </tr>
                        <?php
        $page = request()->page??0;
        $sr = 1 + (($page > 0?$page-1:0) * 10);
    ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($sr++); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td><?php echo e($user->type); ?></td>
                                <td><?php echo e($user->active ? "Active":"Deactive"); ?></td>
                                <td>
                                    <a href="<?php echo e(route('user.status.update',['id'=>$user->id,'status'=>($user->active ? 0:1)])); ?>" class="btn btn-md"><?php echo e($user->active ? "Deactive":"Active"); ?></a> 
                                </td>
                                <td>
                                    <a href="<?php echo e(route('user.edit',['id'=>$user->id])); ?>" class="btn btn-md">Edit</a> 
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                <?php echo e($users->links()); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\leaves\resources\views/profile/list.blade.php ENDPATH**/ ?>